import java.net.*;
import java.io.*;

class TokenServer
  {
      public static DatagramSocket ds;
      public static DatagramPacket dp;

      public static void main(String[] args) throws Exception
         {
	try
	  {
	     ds=new DatagramSocket(1000);  // ds is the object of DatagramSocket at port 1000
                 while(true)
	     {
	       byte buff[]=new byte[1024];
                   // data coming from client is in byte form. This data is stored in buff array
                   // this data is received at server through ds
dp=new DatagramPacket(buff, buff.length);
ds.receive(dp);

                   // data in byte form is converted in string form
	       String str=new String(dp.getData(),0,dp.getLength());

                   // the data received from client is display at server
   	       System.out.println("Message from " +str);
	      }
	  }
	catch(Exception e)
	 {
	    e.printStackTrace();
	}
       }
  }
