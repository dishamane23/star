// RPC
//ChatClient.java
import java.net.*;
import java.io.*;

public class ChatClient
  {
    Socket soc;

    BufferedReader br,br1;
    PrintWriter out;

    String str;

    public ChatClient()  //constructor
      {
        try
        {
          soc = new Socket(InetAddress.getLocalHost(), 9999);

          br = new BufferedReader(new InputStreamReader(System.in));
          out = new PrintWriter(soc.getOutputStream(), true);
          System.out.println("Chat Client Started");

          while (true)
            {
              str = br.readLine();
              out.println(str);
              new InnerClient();
            }
        }
       catch (Exception e)
        {
          e.printStackTrace();
        }
    }

  class InnerClient extends Thread  // inside Chatclient class
    {
      String str1;

      InnerClient()
        {
          try
            {
              br1 = new BufferedReader(new InputStreamReader(soc.getInputStream()));
              start();
            }
          catch (Exception e)
            {
              e.printStackTrace();
            }
        }

      public void run()
        {
          try
            { 
             while (true)
              {
                str1 = br1.readLine();
                System.out.println("Server says : " + str1);
              }
            }
          catch (Exception e)
            {
              e.printStackTrace();
            }
        }
    } // end of InnerClient class

  public static void main(String args[]) // method of outer class ChatClient
    {
      new ChatClient();
    }
}
