//RPC
//ChatServer.java

import java.net.*;
import java.io.*;

public class ChatServer extends Thread
 {
    ServerSocket ss;
    Socket soc;

    BufferedReader br,br1;
    PrintWriter out;

    String str;

    public ChatServer()
        {
            try
            {
                ss = new ServerSocket(9999);
                soc = ss.accept();
                br = new BufferedReader(new InputStreamReader(soc.getInputStream()));
		
		// InputStreamReader ir=new InputStreamReader(soc.getInputStream());
                // br = new BufferedReader(ir);

                System.out.println("Chat Server Started");
		start();
                new InnerServer();
            }
           catch (Exception e)
            {
                e.printStackTrace();
            }
       } 	//end of ChatServer()

   public void run()
      {
        try
        {
            while(true)  // the data coming client is displayed
            {
              str = br.readLine();
              System.out.println("Client says : " + str);
            }
        }
       catch (Exception e)
        {
           e.printStackTrace();
        }
     }   // end of run()


   class InnerServer   // inside ChatServer class
    // the data from server will be read from console and sent to client.
    {
      String str1;

      InnerServer()   // constructor
       {
         try
          {
            br1= new BufferedReader(new InputStreamReader(System.in));
            out = new PrintWriter(soc.getOutputStream(), true);
            while (true) // read the data from br1 and put in 'out'
            {
              //str1 = br1.readLine();
              //out.println(str1);

              out.println(br1.readLine());
            }
          }
        catch (Exception e)
          { e.printStackTrace();   }
      }
   }  // end of InnerSErver class

  public static void main(String args[])  // method of chatServer class
   {
     new ChatServer();
   }
}

